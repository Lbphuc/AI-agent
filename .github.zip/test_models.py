"""Debug API key + test models."""
import os
from pathlib import Path

env_path = Path("c:/IT/Đồ án/ai-agent-bi/.env")

# Đọc .env thủ công để tránh lỗi encoding
print("=== Đọc file .env ===")
content = env_path.read_text(encoding="utf-8-sig", errors="replace")
for line in content.splitlines():
    if "GEMINI" in line:
        key_val = line.split("=", 1)[1].strip() if "=" in line else ""
        print(f"Key (30 ký tự đầu): [{key_val[:30]}]")
        print(f"Độ dài: {len(key_val)}")
        print(f"Format đúng (AIzaSy): {key_val.startswith('AIzaSy')}")
        print(f"Format sai (AQ/AAQ): {key_val.startswith('AQ.') or key_val.startswith('AAQ.')}")

# Test với key đọc thủ công
print("\n=== Test API ===")
try:
    from dotenv import dotenv_values
    vals = dotenv_values(env_path)
    key = vals.get("GEMINI_API_KEY", "").strip()

    from google import genai
    client = genai.Client(api_key=key)

    resp = client.models.generate_content(
        model="gemini-3.5-flash",
        contents="Say hello",
    )
    print(f"OK: {resp.text[:50]}")
except Exception as e:
    print(f"Loi: {str(e)[:150]}")
